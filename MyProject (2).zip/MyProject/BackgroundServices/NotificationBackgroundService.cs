using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using MyProject.Services;
using MyProject.Data;
using MyProject.Models; // Ensure you include this for UserToken
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace MyProject.BackgroundServices
{
    public class NotificationBackgroundService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;

        public NotificationBackgroundService(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            Console.WriteLine("🟢 Notification background service started...");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using var scope = _serviceProvider.CreateScope();
                    var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                    var notificationService = scope.ServiceProvider.GetRequiredService<NotificationService>();

                    // ✅ Get all active tokens where notification has not yet been sent
                    var activeTokens = await context.UserTokens
                        .Where(x => x.IsActive && !x.NotificationSent)
                        .ToListAsync(stoppingToken);

                    foreach (var token in activeTokens)
                    {
                        try
                        {
                            string title = "Hello from Background Service";
                            string body = $"Hi UIN {token.UIN}, this is a test notification.";

                            // Send notification
                            var response = await notificationService.SendNotificationAsync(token.FcmToken, title, body);

                            Console.WriteLine($"📩 Sent to UIN {token.UIN}, Token: {token.FcmToken}, Response: {response}");

                            // ✅ Mark as sent
                            token.NotificationSent = true;
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"⚠️ Failed to send to UIN {token.UIN}: {ex.Message}");
                        }
                    }

                    // Save all changes
                    await context.SaveChangesAsync(stoppingToken);

                    // Wait 20 seconds before next round
                    await Task.Delay(TimeSpan.FromSeconds(2), stoppingToken);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"⚠️ Background service error: {ex.Message}");
                }
            }
        }
    }
}
