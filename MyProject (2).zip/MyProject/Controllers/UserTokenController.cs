using Microsoft.AspNetCore.Mvc;
using MyProject.Services;
using MyProject.Models;
using System;
using System.Threading.Tasks;

namespace MyProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserTokenController : ControllerBase
    {
        private readonly UserTokenService _service;

        public UserTokenController(UserTokenService service)
        {
            _service = service;
        }

        
        [HttpPost("insertOrUpdate")]
        public async Task<IActionResult> InsertOrUpdate([FromBody] TokenRequest request)
        {
            if (!IsValidRequest(request?.UIN ?? 0, request?.FcmToken, request?.MobileNumber))
                return BadRequest(new { Success = false, Message = "Invalid request body" });

            try
            {
                var (success, message, data) = await _service.AddOrUpdateTokenAsync(
                    request!.UIN, request.FcmToken, request.MobileNumber
                );

                return Ok(new { Success = success, Message = message, Data = data });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Success = false, Message = "Server error", Error = ex.Message });
            }
        }


        private static bool IsValidRequest(int uin, string? fcmToken, string? mobileNumber)
        {
            return uin > 0 &&
                   !string.IsNullOrWhiteSpace(fcmToken) &&
                   !string.IsNullOrWhiteSpace(mobileNumber);
        }
    }
}
