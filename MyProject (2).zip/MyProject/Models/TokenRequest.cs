using System.ComponentModel.DataAnnotations;

namespace MyProject.Models
{
    public class TokenRequest
    {
        [Required(ErrorMessage = "UIN is required")]
        [Range(1, int.MaxValue, ErrorMessage = "UIN must be greater than 0")]
        public int UIN { get; set; }  // Unique User Identifier

        [Required(ErrorMessage = "FCM Token is required")]
        [MaxLength(200, ErrorMessage = "FCM Token cannot exceed 200 characters")]
        public string FcmToken { get; set; } = string.Empty;  // ✅ unified with UserToken

        [Required(ErrorMessage = "Mobile number is required")]
        [Phone(ErrorMessage = "Invalid mobile number format")]
        [MaxLength(20, ErrorMessage = "Mobile number cannot exceed 20 characters")]
        public string MobileNumber { get; set; } = string.Empty;
    }
}
