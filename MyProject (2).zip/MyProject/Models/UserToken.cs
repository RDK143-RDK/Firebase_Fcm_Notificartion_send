using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyProject.Models
{
    [Table("UserTokens")]
    public class UserToken
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int UIN { get; set; }

        [Required]
        [MaxLength(200)]
        public string FcmToken { get; set; } = string.Empty;

        [Required]
        [MaxLength(20)]
        public string MobileNumber { get; set; } = string.Empty;

        [Required]
        public bool IsActive { get; set; } = false;

        // ✅ Add this property to track whether notification has been sent
        [Required]
        public bool NotificationSent { get; set; } = false;
    }
}
