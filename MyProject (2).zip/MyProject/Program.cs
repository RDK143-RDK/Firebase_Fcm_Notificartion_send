using Microsoft.EntityFrameworkCore;
using MyProject.Data;
using MyProject.Services;
using MyProject.Repositories;
using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using MyProject.BackgroundServices;

var builder = WebApplication.CreateBuilder(args);

// ✅ Configure PostgreSQL connection
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

// ✅ Register Repository + Services
builder.Services.AddScoped<IUserTokenRepository, UserTokenRepository>();
builder.Services.AddScoped<UserTokenService>();
builder.Services.AddScoped<NotificationService>();

// ✅ Add background hosted service for sending notifications
builder.Services.AddHostedService<NotificationBackgroundService>();

// ✅ Add controllers
builder.Services.AddControllers();

// ✅ Add Swagger (API testing UI)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ✅ Add CORS for Flutter frontend
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFlutter", policy =>
    {
        policy
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader();
    });
});

var app = builder.Build();

// ✅ Initialize Firebase if not already created
if (FirebaseApp.DefaultInstance == null)
{
    var firebaseKeyPath = Path.Combine(app.Environment.ContentRootPath, "firebase-key.json");

    if (!File.Exists(firebaseKeyPath))
    {
        Console.WriteLine($"⚠️ Firebase key file missing: {firebaseKeyPath}");
        throw new FileNotFoundException("Firebase key file not found. Please add firebase-key.json in project root.", firebaseKeyPath);
    }

    FirebaseApp.Create(new AppOptions
    {
        Credential = GoogleCredential.FromFile(firebaseKeyPath)
    });

    Console.WriteLine("✅ Firebase initialized successfully.");
}

// ✅ Middleware pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    // Optional: enable Swagger in production if needed
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseRouting();

// ✅ Enable CORS for Flutter frontend
app.UseCors("AllowFlutter");

// ✅ Map controllers
app.MapControllers();

// ✅ Log startup info
Console.WriteLine("🟢 Backend started. NotificationBackgroundService will send messages every 20 seconds.");

// ✅ Run the app
app.Run();
