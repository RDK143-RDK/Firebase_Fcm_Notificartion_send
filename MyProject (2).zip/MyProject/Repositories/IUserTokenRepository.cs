using MyProject.Models;
using System.Threading.Tasks;

namespace MyProject.Repositories
{
    public interface IUserTokenRepository
    {
        /// <summary>
        /// Add a new FCM token record for a user.
        /// </summary>
        /// <param name="token">The <see cref="UserToken"/> entity to insert.</param>
        /// <returns>The inserted <see cref="UserToken"/>.</returns>
        Task<UserToken> AddTokenAsync(UserToken token);

        /// <summary>
        /// Get a token by FCM token string and mobile number.
        /// </summary>
        /// <param name="fcmToken">The Firebase Cloud Messaging token string.</param>
        /// <param name="mobileNumber">The user’s mobile number.</param>
        /// <returns>The <see cref="UserToken"/> if found, otherwise null.</returns>
        Task<UserToken?> GetTokenAsync(string fcmToken, string mobileNumber);

        /// <summary>
        /// Get a token by UIN, FCM token, and mobile number.
        /// </summary>
        /// <param name="uin">The user’s unique identification number.</param>
        /// <param name="fcmToken">The Firebase Cloud Messaging token string.</param>
        /// <param name="mobileNumber">The user’s mobile number.</param>
        /// <returns>The <see cref="UserToken"/> if found, otherwise null.</returns>
        Task<UserToken?> GetTokenByUinTokenMobileAsync(int uin, string fcmToken, string mobileNumber);

        /// <summary>
        /// Get token details by UIN only.
        /// </summary>
        /// <param name="uin">The user’s unique identification number.</param>
        /// <returns>The <see cref="UserToken"/> if found, otherwise null.</returns>
        Task<UserToken?> GetByUinAsync(int uin);

        /// <summary>
        /// Deactivate all active tokens for a specific FCM token and mobile number.
        /// </summary>
        /// <param name="fcmToken">The Firebase Cloud Messaging token string.</param>
        /// <param name="mobileNumber">The user’s mobile number.</param>
        Task DeactivateTokensAsync(string fcmToken, string mobileNumber);
    }
}
