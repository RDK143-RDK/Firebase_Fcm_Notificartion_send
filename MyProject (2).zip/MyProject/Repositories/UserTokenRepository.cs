using Microsoft.EntityFrameworkCore;
using MyProject.Data;
using MyProject.Models;
using System.Linq;
using System.Threading.Tasks;

namespace MyProject.Repositories
{
    public class UserTokenRepository : IUserTokenRepository
    {
        private readonly AppDbContext _context;

        public UserTokenRepository(AppDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Add a new user token record to the database.
        /// </summary>
        public async Task<UserToken> AddTokenAsync(UserToken token)
        {
            await _context.UserTokens.AddAsync(token);
            await _context.SaveChangesAsync();
            return token;
        }

        /// <summary>
        /// Get a user token by FCM token and mobile number.
        /// </summary>
        public async Task<UserToken?> GetTokenAsync(string fcmToken, string mobileNumber)
        {
            return await _context.UserTokens
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.FcmToken == fcmToken && x.MobileNumber == mobileNumber);
        }

        /// <summary>
        /// Get a user token by UIN, FCM token, and mobile number.
        /// </summary>
        public async Task<UserToken?> GetTokenByUinTokenMobileAsync(int uin, string fcmToken, string mobileNumber)
        {
            return await _context.UserTokens
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.UIN == uin && x.FcmToken == fcmToken && x.MobileNumber == mobileNumber);
        }

        /// <summary>
        /// Get the latest token details by UIN only.
        /// </summary>
        public async Task<UserToken?> GetByUinAsync(int uin)
        {
            return await _context.UserTokens
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.UIN == uin);
        }

        /// <summary>
        /// Deactivate all active tokens for the given FCM token and mobile number.
        /// </summary>
        public async Task DeactivateTokensAsync(string fcmToken, string mobileNumber)
        {
            var tokens = await _context.UserTokens
                .Where(x => x.FcmToken == fcmToken && x.MobileNumber == mobileNumber && x.IsActive)
                .ToListAsync();

            if (tokens.Any())
            {
                foreach (var t in tokens)
                {
                    t.IsActive = false;
                }

                await _context.SaveChangesAsync();
            }
        }
    }
}
