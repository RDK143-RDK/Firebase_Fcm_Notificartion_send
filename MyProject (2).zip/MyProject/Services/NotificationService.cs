using FirebaseAdmin.Messaging;
using System;
using System.Threading.Tasks;

namespace MyProject.Services
{
    public class NotificationService
    {
        /// <summary>
        /// Send a welcome/login success notification for a user using their UIN.
        /// </summary>
        /// <param name="token">Firebase FCM token</param>
        /// <param name="uin">User UIN</param>
        /// <returns>Message ID or error string</returns>
        public async Task<string> SendWelcomeMessageAsync(string token, int uin)
        {
            string title = "Login Successful ✅";
            string body = $"Welcome! Your UIN is {uin}";

            return await SendNotificationAsync(token, title, body);
        }

        /// <summary>
        /// Generic reusable method to send any FCM notification.
        /// </summary>
        /// <param name="token">Firebase FCM token</param>
        /// <param name="title">Notification title</param>
        /// <param name="body">Notification body</param>
        /// <returns>Message ID from FCM or error string</returns>
        public async Task<string> SendNotificationAsync(string token, string title, string body)
        {
            if (string.IsNullOrWhiteSpace(token))
            {
                return "Error: Token is null or empty";
            }

            try
            {
                var message = new Message
                {
                    Token = token,
                    Notification = new Notification
                    {
                        Title = title,
                        Body = body
                    }
                };

                // Send notification via Firebase
                string response = await FirebaseMessaging.DefaultInstance.SendAsync(message);

                Console.WriteLine($"📩 FCM sent successfully. Token: {token}, Title: {title}, Response: {response}");
                return response; // messageId returned by FCM
            }
            catch (Exception ex)
            {
                Console.WriteLine($"⚠️ FCM send error. Token: {token}, Title: {title}, Error: {ex.Message}");
                return $"Error: {ex.Message}";
            }
        }
    }
}
