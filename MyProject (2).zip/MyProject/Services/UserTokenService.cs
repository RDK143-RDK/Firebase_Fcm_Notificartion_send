using MyProject.Models;
using MyProject.Repositories;
using System.Threading.Tasks;

namespace MyProject.Services
{
    public class UserTokenService
    {
        private readonly IUserTokenRepository _repository;

        public UserTokenService(IUserTokenRepository repository)
        {
            _repository = repository;
        }

        public async Task<(bool Success, string Message, UserToken? Data)> AddOrUpdateTokenAsync(
            int uin, string fcmToken, string mobileNumber)
        {
            if (!IsValidInput(uin, fcmToken, mobileNumber))
                return (false, "Invalid input provided", null);

            // 1. Check if exact same record exists
            var existing = await _repository.GetTokenByUinTokenMobileAsync(uin, fcmToken, mobileNumber);
            if (existing is not null)
                return (false, "User already registered with this FCM token", existing);

            // 2. Check if same UIN exists with different token or mobile
            var sameUin = await _repository.GetByUinAsync(uin);
            if (sameUin is not null && (sameUin.FcmToken != fcmToken || sameUin.MobileNumber != mobileNumber))
                return (false, "UIN already exists with different token or mobile number", sameUin);

            // 3. Deactivate old tokens for same FCM token + mobile
            await _repository.DeactivateTokensAsync(fcmToken, mobileNumber);

            // 4. Insert new active token
            var newToken = new UserToken
            {
                UIN = uin,
                FcmToken = fcmToken,
                MobileNumber = mobileNumber,
                IsActive = true
            };

            var inserted = await _repository.AddTokenAsync(newToken);
            return (true, "Token inserted successfully", inserted);
        }

        /// <summary>
        /// Check if a specific UIN + FCM token + MobileNumber combination is active.
        /// </summary>
        public async Task<(bool Success, string Message, UserToken? Data)> CheckTokenStatusAsync(
            int uin, string fcmToken, string mobileNumber)
        {
            if (!IsValidInput(uin, fcmToken, mobileNumber))
                return (false, "Invalid input provided", null);

            var tokenEntry = await _repository.GetTokenByUinTokenMobileAsync(uin, fcmToken, mobileNumber);

            if (tokenEntry is null)
                return (false, "No record found", null);

            if (!tokenEntry.IsActive)
                return (false, "Record found but inactive", tokenEntry);

            return (true, "Record is active", tokenEntry);
        }

        /// <summary>
        /// Common input validation helper
        /// </summary>
        private static bool IsValidInput(int uin, string fcmToken, string mobileNumber)
        {
            return uin > 0 &&
                   !string.IsNullOrWhiteSpace(fcmToken) &&
                   !string.IsNullOrWhiteSpace(mobileNumber);
        }
    }
}
